function main
% This script is a demonstration of how to get the HVSR evolution
% from seismograms recorded by KiK-net station FHSH19 during the 2011 
% Mw 9.0 Tohoku earthquake.
% It can also be used for other nonstationary seismic signal analysis.
% Author: Hao Zhang, HUST, Wuhan China
% Date Created: 11 Jan 2021
% E-mail: zhanghao1037@foxmail.com
%--------------------------------------------------------------------------
% Input parameters:
%   station name
%   well-log time-average velocity 
%   LB: low boundary of the filter 
%   HB: high boundary of the filter 
%   step: moving step length of the time window 
%   band_width: width of the time window 
%   SBW: width of the smoothing window
%   s0: interpolation parameter
%   fc: cut frequency
%--------------------------------------------------------------------------
% Abbreviation:
%   S: correspond to the shear wave
%   P: correspond to the compression wave
%   temp: temporary
%   evo: envelope
%   ST: short time
%   STFT: short time Fourier transform
%--------------------------------------------------------------------------
kikname={'FKSH19'};
global LB HB band_width step SBW s0 fc
LB=1; HB=40; step=1; band_width=10.24;SBW=1.5;s0=4000;fc=40;
%-------------------------------------------------------------------------
vs_soil=255;
vp_soil=520;
path=[kikname{1,1},'1103111446'];
[rs_P,rb_P,f]=text_read_P(path);
[rs_S,rb_S,~]=text_read_S(path);
%-------------------------------------------------------------------------
temp_pgv_S=integral_fre(rs_S,f)/100;
temp_pgv_P=integral_fre(rs_P,f)/100;
evo_temp_pgv_S=max(abs(temp_pgv_S),[],2);
evo_temp_pgv_P=abs(temp_pgv_P);
[~,~,pgv_S]=ST(evo_temp_pgv_S(1:length(rs_S)),f,band_width,step);
[~,~,pgv_P]=ST(evo_temp_pgv_P(1:length(rs_S)),f,band_width,step);
shear_strain=(max(abs(pgv_S.*repmat(parzenwin(size(pgv_S,1)),1,size(pgv_S,2)))))'./vs_soil;
normal_strain=(max(abs(pgv_P.*repmat(parzenwin(size(pgv_S,1)),1,size(pgv_S,2)))))'./vp_soil;
%-------------------------------------------------------------------------
[u,F,re_hvsr]=HVSR_STFT(rs_S,rs_P,f,LB,HB,band_width,step,SBW,s0,fc);
[u_hvsr,F_hvsr]=meshgrid(u,F);
%-------------------------------------------------------------------------
figure (1)
pcolor(u_hvsr,F_hvsr,re_hvsr(:,:,1));shading flat;
colormap(jet);colorbar;
ylim([0,20])
xlim([0,300])
xlabel('Time (s)')
ylabel('Frequency (Hz)')
title('normalized HVSR')
figure (2)
subplot (1,2,1)
plot (u,shear_strain)
xlabel('Time (s)')
ylabel('shear strain')
title('shear strain evolution')
subplot (1,2,2)
plot (u,normal_strain)
xlabel('Time (s)')
ylabel('normal strain')
title('normal strain evolution')  
end
%==========================================================================
function [rs,rb,f]=text_read_S(path)
ew1=textread([path,'.EW1'],'%f','headerlines',17);
ew2=textread([path,'.EW2'],'%f','headerlines',17);
ns1=textread([path,'.NS1'],'%f','headerlines',17);
ns2=textread([path,'.NS2'],'%f','headerlines',17);
f=textread([path,'.EW1'],'%*s%*s%n',1,'headerlines',10);
[kb1,kb2]=textread([path,'.EW1'],'%*s%*s%n%*6s%n',1,'headerlines',13);
[ks1,ks2]=textread([path,'.EW2'],'%*s%*s%n%*6s%n',1,'headerlines',13);
kb=kb1/kb2;
ks=ks1/ks2;
rbew=(ew1-mean(ew1))*kb;
rsew=(ew2-mean(ew2))*ks;
rbns=(ns1-mean(ns1))*kb;
rsns=(ns2-mean(ns2))*ks;
th=(0:17)/18*pi;
rs=rsew*cos(th)+rsns*sin(th);
rb=rbew*cos(th)+rbns*sin(th);
end
function [rsud,rbud,f]=text_read_P(path)
UD1=textread([path,'.UD1'],'%f','headerlines',17);
UD2=textread([path,'.UD2'],'%f','headerlines',17);
f=textread([path,'.EW1'],'%*s%*s%n',1,'headerlines',10);
[ku21,ku22]=textread([path,'.UD2'],'%*s%*s%n%*6s%n',1,'headerlines',13);
[ku11,ku12]=textread([path,'.UD1'],'%*s%*s%n%*6s%n',1,'headerlines',13);
kud1=ku11/ku12;
kud2=ku21/ku22;
rbud=(UD1-mean(UD1))*kud1;
rsud=(UD2-mean(UD2))*kud2;
end
%==========================================================================
function [u,F2,re_hvsr]=HVSR_STFT(rs_S,rs_P,f,LB,HB,band_width,step,SBW,s0,fc)
for j=1:size(rs_S,2)
    [u,F,re_s]=ST(rs_S(:,j),f,band_width,step);
    [u,F,re_b]=ST(rs_P,f,band_width,step);
    [b,a]=butter(4,[LB,HB]/(f/2));
    re_s=filter(b,a,re_s);
    s=2^nextpow2(size(re_s,1));
    rs_fft=abs(fft(re_s,s));
    rb_fft=abs(fft(re_b,s));
    w=parzenwin(ceil(s/100*SBW))/sum(parzenwin(ceil(s/100*SBW)));
    rs_fft=imfilter(rs_fft,w,'symmetric','same');
    rb_fft=imfilter(rb_fft,w,'symmetric','same');
    tf_j=rs_fft./rb_fft;
    F=(0:f/s:f-f/s)';
    I=F<fc;
    F2=(0:fc/s0:fc-fc/s0)';
    re_hvsr(:,:,j)=interp1(F(I),tf_j(I,:),F2,'linear','extrap');
    re_hvsr(:,:,j)= re_hvsr(:,:,j)./max(re_hvsr(:,:,j));
end
end
function [u,F,re_s]=ST(rs,f,tband,step)
b=fix(tband*f);
n=step*f;
m=fix(length(rs)/(step*f));
for i=1:m-fix(b/n)-1
   temp=rs((i-1)*n+1:(i-1)*n+b);
   temp=temp-mean(temp);
   re_s(:,i)=temp.*tukeywin(b,0.05);
   u(i)=step*(i-1)+tband/2;   
end
F=(0:f/2^nextpow2(b):f-f/2^nextpow2(b))';
end
%==========================================================================
function pgv=integral_fre(rs,f) 

s=size(rs,1);
fft_rs=fft(rs,2^nextpow2(s));
F_half=(0:f/(2^nextpow2(s)-2):f/2)';
F=[F_half;-flipdim(F_half,1)];
I=(abs(F)>=0.3&abs(F)<13);
temp_pgv_fre=-fft_rs./repmat(F,1,size(rs,2))*1i;
temp_pgv_fre(~I,:)=0;
temp_pgv=real(ifft(temp_pgv_fre));
pgv=(real(ifft(temp_pgv_fre)));

end
%==========================================================================


